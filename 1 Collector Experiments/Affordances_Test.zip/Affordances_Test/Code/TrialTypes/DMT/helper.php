<?php
    $outputColumns = array('Initial_History', 'Btn_Assignment', 'Choice', 'ChoiceCode', 'Score', 'dmtRT');
