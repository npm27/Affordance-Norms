<?php
    $compTime = 8;    // time in seconds to use for 'computer' timing
