<div><?php echo $text; ?></div>
  
<!-- show the image -->
<div class="pic">
    <?php echo show($cue); ?>
</div>
  
<!-- show the answer -->
<h2 class="textcenter"><?php echo $answer; ?></h2>

<!-- response and RT form -->
<div class="textcenter">
    <button class="collectorButton collectorAdvance" id="FormSubmitButton" autofocus>Next</button>
</div>