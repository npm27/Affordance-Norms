<div class="pic"><?php echo show($cue); ?></div>
<div><?php echo $text; ?></div>
<div class="textcenter">
    <input class="testPic collectorInput" name="Response" id="Response" type="text" value="" autocomplete="off">
    <button class="collectorButton"  id="FormSubmitButton">Submit</button>
</div>