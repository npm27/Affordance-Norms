<?php
    $outputColumns = array('RT', 'Response', 'Accuracy', 'RTfirst', 'RTlast', 'strictAcc', 'lenientAcc', 'focus');
